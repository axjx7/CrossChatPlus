#!/bin/bash
# CrossChatPlus 一键推送到 GitHub
# 用法: 在 Termux 中执行 bash push.sh

echo "=== CrossChatPlus 自动发布脚本 ==="

# 检查 git
if ! command -v git &> /dev/null; then
    echo "正在安装 git..."
    pkg install git -y
fi

# 检查运行目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || { echo "错误: 无法进入项目目录"; exit 1; }

# 提示输入仓库地址
read -p "输入你的 GitHub 仓库地址 (例如 https://github.com/用户名/CrossChatPlus.git): " REPO_URL

# 初始化仓库（如果还没有）
if [ ! -d ".git" ]; then
    git init
    git branch -M main
fi

git add .
git commit -m "auto: $(date +%Y-%m-%d_%H:%M)"

git remote remove origin 2>/dev/null
git remote add origin "$REPO_URL"

echo ""
echo "正在推送...(需要输入 GitHub Personal Access Token 作为密码)"
echo "如果没有 token，请前往 GitHub Settings -> Developer settings -> Personal access tokens -> Tokens (classic) 生成"
git push -u origin main
