package com.crosschatplus.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.crosschatplus.CrossChatPlus;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final File file;

    // Chat Bridge
    public String wsUrl = "ws://127.0.0.1:8080/chat";
    public String nickname = "Player";
    public boolean chatBridgeEnabled = true;
    public boolean showCrossChatPrefix = true;
    public String crossChatPrefix = "[§b跨服§r]";

    // Skin Cache
    public boolean skinCacheEnabled = true;
    public int skinCacheMaxAgeDays = 7;
    public String skinCacheDir = "cache/skins";

    // Theme
    public boolean themeEnabled = false;
    public String activeTheme = "default";

    // Nac4399
    public boolean nac4399Enabled = false;
    public String nac4399ApiUrl = "https://api.nac4399.com/account/random";

    // Reconnect
    public int reconnectDelayMs = 5000;
    public int maxReconnectAttempts = 0; // 0 = unlimited

    public ModConfig(File file) {
        this.file = file;
    }

    public void load() {
        if (!file.exists()) {
            save();
            CrossChatPlus.LOGGER.info("Created default config at {}", file.getAbsolutePath());
            return;
        }
        try (Reader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
            if (loaded != null) {
                this.wsUrl = loaded.wsUrl;
                this.nickname = loaded.nickname;
                this.chatBridgeEnabled = loaded.chatBridgeEnabled;
                this.showCrossChatPrefix = loaded.showCrossChatPrefix;
                this.crossChatPrefix = loaded.crossChatPrefix;
                this.skinCacheEnabled = loaded.skinCacheEnabled;
                this.skinCacheMaxAgeDays = loaded.skinCacheMaxAgeDays;
                this.skinCacheDir = loaded.skinCacheDir;
                this.themeEnabled = loaded.themeEnabled;
                this.activeTheme = loaded.activeTheme;
                this.nac4399Enabled = loaded.nac4399Enabled;
                this.nac4399ApiUrl = loaded.nac4399ApiUrl;
                this.reconnectDelayMs = loaded.reconnectDelayMs;
                this.maxReconnectAttempts = loaded.maxReconnectAttempts;
            }
        } catch (IOException e) {
            CrossChatPlus.LOGGER.error("Failed to load config, using defaults", e);
        }
    }

    public void save() {
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            CrossChatPlus.LOGGER.error("Failed to save config", e);
        }
    }

    public void reload() {
        load();
    }
}
