package com.crosschatplus;

import com.crosschatplus.chat.ChatBridge;
import com.crosschatplus.config.ModConfig;
import com.crosschatplus.skin.SkinCache;
import com.crosschatplus.theme.ThemeManager;
import com.crosschatplus.nac.Nac4399Helper;
import com.crosschatplus.command.ModCommands;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.nio.file.Path;

@Mod(CrossChatPlus.MOD_ID)
public class CrossChatPlus {
    public static final String MOD_ID = "crosschatplus";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static Path CONFIG_DIR;

    private static CrossChatPlus instance;
    private ModConfig config;
    private ChatBridge chatBridge;
    private SkinCache skinCache;
    private ThemeManager themeManager;
    private Nac4399Helper nacHelper;

    public CrossChatPlus() {
        instance = this;
        CONFIG_DIR = FMLPaths.GAMEDIR.get().resolve("config").resolve(MOD_ID);
        CONFIG_DIR.toFile().mkdirs();

        config = new ModConfig(CONFIG_DIR.resolve("config.json").toFile());
        config.load();

        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::onCommonSetup);
        modBus.addListener(this::onClientSetup);

        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("CrossChatPlus initialized. Config at: {}", CONFIG_DIR);
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        ModCommands.register();
        LOGGER.info("CrossChatPlus common setup complete.");
    }

    private void onClientSetup(FMLClientSetupEvent event) {
        skinCache = new SkinCache(config);
        themeManager = new ThemeManager(config);
        chatBridge = new ChatBridge(config, MinecraftForge.EVENT_BUS);
        nacHelper = new Nac4399Helper(config);

        chatBridge.connect();
        LOGGER.info("CrossChatPlus client setup complete.");
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("CrossChatPlus server starting.");
    }

    public static CrossChatPlus getInstance() { return instance; }
    public ModConfig getConfig() { return config; }
    public ChatBridge getChatBridge() { return chatBridge; }
    public SkinCache getSkinCache() { return skinCache; }
    public ThemeManager getThemeManager() { return themeManager; }
    public Nac4399Helper getNacHelper() { return nacHelper; }
}
