package com.crosschatplus.theme;

import com.crosschatplus.config.ModConfig;
import com.crosschatplus.CrossChatPlus;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class ThemeManager {
    private final ModConfig config;
    private final Path themesDir;
    private final Map<String, Theme> loadedThemes = new HashMap<>();
    private Theme activeTheme;
    private static final Gson GSON = new Gson();

    public ThemeManager(ModConfig config) {
        this.config = config;
        this.themesDir = CrossChatPlus.CONFIG_DIR.resolve("themes");
        try {
            Files.createDirectories(themesDir);
        } catch (IOException e) {
            CrossChatPlus.LOGGER.error("Failed to create themes dir", e);
        }
        loadTheme("default");
        if (config.themeEnabled && !"default".equals(config.activeTheme)) {
            loadTheme(config.activeTheme);
        }
        activeTheme = loadedThemes.get(config.activeTheme);
        if (activeTheme == null) activeTheme = loadedThemes.get("default");
    }

    public void setTheme(String name) {
        loadTheme(name);
        Theme theme = loadedThemes.get(name);
        if (theme != null) {
            activeTheme = theme;
            config.activeTheme = name;
            config.themeEnabled = true;
            config.save();
            CrossChatPlus.LOGGER.info("Theme switched to: {}", name);
        } else {
            CrossChatPlus.LOGGER.warn("Theme '{}' not found.", name);
        }
    }

    private void loadTheme(String name) {
        if (loadedThemes.containsKey(name)) return;

        // 1. 尝试从 config/themes/ 加载自定义主题
        Path customTheme = themesDir.resolve(name + ".json");
        if (Files.exists(customTheme)) {
            try {
                String content = Files.readString(customTheme);
                loadedThemes.put(name, GSON.fromJson(content, Theme.class));
                CrossChatPlus.LOGGER.info("Loaded custom theme: {}", name);
                return;
            } catch (IOException e) {
                CrossChatPlus.LOGGER.warn("Failed to load custom theme {}", name, e);
            }
        }

        // 2. 尝试从 mod 资源加载内置主题
        try (InputStream in = getClass().getClassLoader()
                .getResourceAsStream("assets/crosschatplus/themes/" + name + ".json")) {
            if (in != null) {
                String content = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                loadedThemes.put(name, GSON.fromJson(content, Theme.class));
                CrossChatPlus.LOGGER.info("Loaded built-in theme: {}", name);
                return;
            }
        } catch (IOException e) {
            CrossChatPlus.LOGGER.warn("Failed to load built-in theme {}", name, e);
        }

        CrossChatPlus.LOGGER.warn("Theme '{}' not found in any location.", name);
    }

    public List<String> getAvailableThemes() {
        Set<String> names = new LinkedHashSet<>(loadedThemes.keySet());
        // Scan built-in
        try {
            var resources = getClass().getClassLoader().getResources("assets/crosschatplus/themes/");
            while (resources.hasMoreElements()) {
                var url = resources.nextElement();
                if ("file".equals(url.getProtocol())) {
                    Files.list(Path.of(url.toURI()))
                            .filter(p -> p.toString().endsWith(".json"))
                            .map(p -> p.getFileName().toString().replace(".json", ""))
                            .forEach(names::add);
                }
            }
        } catch (Exception ignored) {}
        // Scan custom
        try (var files = Files.list(themesDir)) {
            files.filter(p -> p.toString().endsWith(".json"))
                    .map(p -> p.getFileName().toString().replace(".json", ""))
                    .forEach(names::add);
        } catch (IOException ignored) {}
        return new ArrayList<>(names);
    }

    public Theme getActiveTheme() { return activeTheme; }
    public boolean isThemeEnabled() { return config.themeEnabled; }

    // 颜色/样式查询封装
    public int getColor(String key, int defaultColor) {
        if (!config.themeEnabled || activeTheme == null) return defaultColor;
        return activeTheme.colors.getOrDefault(key, defaultColor);
    }

    public static class Theme {
        public String name = "default";
        public String author = "CrossChatPlus";
        public String description = "Default theme";
        public Map<String, Integer> colors = new HashMap<>();
        public Map<String, String> fonts = new HashMap<>();
        public Map<String, String> textures = new HashMap<>();
    }
}
