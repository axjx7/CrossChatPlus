package com.crosschatplus.mixin;

import com.crosschatplus.CrossChatPlus;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook Minecraft 主循环，用于注入主题颜色和资源覆盖
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Inject(method = "runTick", at = @At("HEAD"))
    private void onRunTick(CallbackInfo ci) {
        // 每 tick 检查主题状态，预留动态主题切换入口
        var themeManager = CrossChatPlus.getInstance().getThemeManager();
        if (themeManager != null && themeManager.isThemeEnabled()) {
            // 未来可在这里注入 BufferedImage 覆盖 GUI 纹理
        }
    }
}
