package com.crosschatplus.mixin;

import com.crosschatplus.gui.CrossChatScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin {

    @Inject(at = @At("RETURN"), method = "init")
    private void onInit(CallbackInfo ci) {
        TitleScreen screen = (TitleScreen)(Object)this;
        int midX = screen.width / 2;
        int y = screen.height / 4 + 100;  // 放在原有按钮下方

        screen.addRenderableWidget(
                Button.builder(
                        Component.literal("§d◆ 跨服聊天"),
                        btn -> Minecraft.getInstance().setScreen(new CrossChatScreen())
                )
                .bounds(midX - 100, y, 200, 20)
                .build()
        );
    }
}
