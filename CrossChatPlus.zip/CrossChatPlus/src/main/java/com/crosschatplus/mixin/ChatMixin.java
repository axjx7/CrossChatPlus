package com.crosschatplus.mixin;

import com.crosschatplus.CrossChatPlus;
import net.minecraft.client.multiplayer.chat.ChatListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.PlayerChatMessage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 拦截服务器发来的聊天消息 → 如果包含跨服标记则渲染成特殊样式
 */
@Mixin(ChatListener.class)
public class ChatMixin {

    @Inject(method = "handlePlayerChatMessage", at = @At("HEAD"))
    private void onHandlePlayerChat(PlayerChatMessage message, Component decorated, CallbackInfo ci) {
        String content = message.signedContent();
        if (content != null && content.startsWith("[CrossChat]")) {
            // 跨服消息，修改样式逻辑可以在这里标记
            // 实际渲染由 ChatBridge.onMessage 内 Component.literal 已完成
            // 此 mixin 为 future 扩展保留
        }
    }

    @Inject(method = "handleSystemMessage", at = @At("HEAD"))
    private void onHandleSystem(Component message, CallbackInfo ci) {
        // 系统消息 hook 预留
    }
}
