package com.crosschatplus.skin;

import com.crosschatplus.config.ModConfig;
import com.crosschatplus.CrossChatPlus;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;

public class SkinCache {
    private final ModConfig config;
    private final Path cacheRoot;
    private final Gson gson = new Gson();

    public SkinCache(ModConfig config) {
        this.config = config;
        this.cacheRoot = CrossChatPlus.CONFIG_DIR.resolve(config.skinCacheDir);
        try {
            Files.createDirectories(cacheRoot);
        } catch (IOException e) {
            CrossChatPlus.LOGGER.error("Failed to create skin cache dir", e);
        }
    }

    public String getSkinUrl(String playerName) {
        if (!config.skinCacheEnabled) {
            return fetchSkinUrlFromMojang(playerName);
        }

        String cacheKey = hash(playerName);
        Path metaFile = cacheRoot.resolve(cacheKey + ".json");
        Path skinFile = cacheRoot.resolve(cacheKey + ".png");

        if (Files.exists(metaFile) && Files.exists(skinFile)) {
            try {
                String metaStr = Files.readString(metaFile);
                JsonObject meta = JsonParser.parseString(metaStr).getAsJsonObject();
                long cachedAt = meta.get("cachedAt").getAsLong();
                long maxAge = config.skinCacheMaxAgeDays * 86400L * 1000L;
                if (Instant.now().toEpochMilli() - cachedAt < maxAge) {
                    // 缓存有效，返回本地文件路径
                    return skinFile.toUri().toString();
                }
            } catch (IOException e) {
                CrossChatPlus.LOGGER.warn("Skin cache meta read failed", e);
            }
        }

        // 缓存失效或不存在，从远端拉取
        String skinUrl = fetchSkinUrlFromMojang(playerName);
        if (skinUrl != null) {
            downloadAndCache(playerName, cacheKey, skinUrl, metaFile, skinFile);
        }
        return skinUrl;
    }

    private String fetchSkinUrlFromMojang(String playerName) {
        try {
            // Step 1: UUID -> Profile
            URL uuidUrl = new URL("https://api.mojang.com/users/profiles/minecraft/" + playerName);
            HttpURLConnection conn = (HttpURLConnection) uuidUrl.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                CrossChatPlus.LOGGER.warn("Mojang API returned {} for {}", responseCode, playerName);
                return null;
            }

            String body = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            conn.disconnect();

            JsonObject profile = JsonParser.parseString(body).getAsJsonObject();
            String uuid = profile.get("id").getAsString();

            // Step 2: Profile -> Textures
            URL sessionUrl = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid);
            HttpURLConnection sessionConn = (HttpURLConnection) sessionUrl.openConnection();
            sessionConn.setConnectTimeout(5000);
            sessionConn.setReadTimeout(5000);

            String sessionBody = new String(sessionConn.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            sessionConn.disconnect();

            // 解析 textures 中的 skin url
            JsonObject sessionData = JsonParser.parseString(sessionBody).getAsJsonObject();
            if (sessionData.has("properties")) {
                var props = sessionData.getAsJsonArray("properties");
                for (var prop : props) {
                    JsonObject p = prop.getAsJsonObject();
                    if ("textures".equals(p.get("name").getAsString())) {
                        String encoded = p.get("value").getAsString();
                        String decoded = new String(java.util.Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);
                        JsonObject textures = JsonParser.parseString(decoded).getAsJsonObject();
                        JsonObject skinObj = textures.getAsJsonObject("textures").getAsJsonObject("SKIN");
                        if (skinObj != null && skinObj.has("url")) {
                            return skinObj.get("url").getAsString();
                        }
                    }
                }
            }
        } catch (Exception e) {
            CrossChatPlus.LOGGER.warn("Failed to fetch skin for " + playerName, e);
        }
        return null;
    }

    private void downloadAndCache(String playerName, String cacheKey, String skinUrl, Path metaFile, Path skinFile) {
        try {
            // Download PNG
            URL url = new URL(skinUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("User-Agent", "CrossChatPlus/1.0");

            try (InputStream in = conn.getInputStream()) {
                Files.copy(in, skinFile, StandardCopyOption.REPLACE_EXISTING);
            }
            conn.disconnect();

            // Write meta
            JsonObject meta = new JsonObject();
            meta.addProperty("playerName", playerName);
            meta.addProperty("cachedAt", Instant.now().toEpochMilli());
            meta.addProperty("sourceUrl", skinUrl);
            Files.writeString(metaFile, gson.toJson(meta));

            CrossChatPlus.LOGGER.info("Cached skin for {} at {}", playerName, skinFile);
        } catch (IOException e) {
            CrossChatPlus.LOGGER.warn("Failed to cache skin for " + playerName, e);
        }
    }

    private String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            return Integer.toHexString(input.hashCode());
        }
    }

    public void clearCache() {
        try (var files = Files.list(cacheRoot)) {
            files.forEach(f -> {
                try { Files.delete(f); } catch (IOException ignored) {}
            });
            CrossChatPlus.LOGGER.info("Skin cache cleared.");
        } catch (IOException e) {
            CrossChatPlus.LOGGER.error("Failed to clear skin cache", e);
        }
    }
}
