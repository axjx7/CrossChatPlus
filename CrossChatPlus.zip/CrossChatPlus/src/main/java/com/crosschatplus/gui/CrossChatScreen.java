package com.crosschatplus.gui;

import com.crosschatplus.CrossChatPlus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CrossChatScreen extends Screen {

    private EditBox messageInput;
    private Button sendBtn;
    private Button connectBtn;
    private Button disconnectBtn;
    private Button nacBtn;
    private Button themeBtn;
    private Button closeBtn;

    private String statusText = "检查中...";
    private long lastStatusCheck = 0;

    protected CrossChatScreen() {
        super(Component.literal("§l跨服聊天"));
    }

    @Override
    protected void init() {
        int midX = this.width / 2;
        int y = 40;

        // 消息输入框
        this.messageInput = new EditBox(this.font, midX - 100, y, 200, 20, Component.literal("输入消息"));
        this.messageInput.setMaxLength(256);
        this.addRenderableWidget(this.messageInput);
        y += 30;

        // 发送按钮
        this.sendBtn = Button.builder(Component.literal("§a发送消息"), btn -> {
                    String msg = this.messageInput.getValue();
                    if (!msg.isEmpty()) {
                        CrossChatPlus.getInstance().getChatBridge().sendChat(msg);
                        this.messageInput.setValue("");
                    }
                })
                .bounds(midX - 100, y, 200, 20)
                .build();
        this.addRenderableWidget(this.sendBtn);
        y += 28;

        // 连接 / 断开
        this.connectBtn = Button.builder(Component.literal("§a连接桥接"), btn -> {
                    CrossChatPlus.getInstance().getChatBridge().connect();
                })
                .bounds(midX - 100, y, 95, 20)
                .build();
        this.addRenderableWidget(this.connectBtn);

        this.disconnectBtn = Button.builder(Component.literal("§c断开"), btn -> {
                    CrossChatPlus.getInstance().getChatBridge().disconnect();
                })
                .bounds(midX + 5, y, 95, 20)
                .build();
        this.addRenderableWidget(this.disconnectBtn);
        y += 28;

        // Nac4399 获取账号
        this.nacBtn = Button.builder(Component.literal("§6获取随机账号"), btn -> {
                    CrossChatPlus.LOGGER.info("Fetching random account...");
                    // 异步请求防止卡界面
                    new Thread(() -> {
                        var account = CrossChatPlus.getInstance().getNacHelper().fetchRandomAccount();
                        if (account != null && account.isValid()) {
                            Minecraft.getInstance().execute(() -> {
                                this.messageInput.setValue("账号: " + account.username + " / 密码: " + account.password);
                            });
                        }
                    }).start();
                })
                .bounds(midX - 100, y, 200, 20)
                .build();
        this.addRenderableWidget(this.nacBtn);
        y += 28;

        // 切换主题
        this.themeBtn = Button.builder(Component.literal("§d切换主题"), btn -> {
                    var themes = CrossChatPlus.getInstance().getThemeManager().getAvailableThemes();
                    String current = CrossChatPlus.getInstance().getConfig().activeTheme;
                    int idx = themes.indexOf(current);
                    String next = themes.get((idx + 1) % themes.size());
                    CrossChatPlus.getInstance().getThemeManager().setTheme(next);
                })
                .bounds(midX - 100, y, 200, 20)
                .build();
        this.addRenderableWidget(this.themeBtn);
        y += 28;

        // 关闭
        this.closeBtn = Button.builder(Component.literal("§7关闭"), btn -> {
                    this.onClose();
                })
                .bounds(midX - 100, y, 200, 20)
                .build();
        this.addRenderableWidget(this.closeBtn);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);

        // 标题
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);

        // 连接状态（每秒刷新）
        long now = System.currentTimeMillis();
        if (now - lastStatusCheck > 1000) {
            lastStatusCheck = now;
            boolean connected = CrossChatPlus.getInstance().getChatBridge().isConnected();
            statusText = connected ? "§a● 已连接" : "§c● 未连接";
        }
        graphics.drawString(this.font, "状态: " + statusText, this.width / 2 - 100, 160, 0xAAAAAA);

        // 配置信息
        String wsInfo = "§7桥接: " + CrossChatPlus.getInstance().getConfig().wsUrl;
        graphics.drawString(this.font, wsInfo, this.width / 2 - 100, 175, 0x888888);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false; // 不暂停游戏
    }
}
