package com.crosschatplus.command;

import com.crosschatplus.CrossChatPlus;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CrossChatPlus.MOD_ID)
public class ModCommands {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("crosschat")
                .then(Commands.literal("send")
                        .then(Commands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    String msg = StringArgumentType.getString(ctx, "message");
                                    CrossChatPlus.getInstance().getChatBridge().sendChat(msg);
                                    ctx.getSource().sendSuccess(
                                            Component.literal("§7[CrossChat] 消息已发送"), false);
                                    return 1;
                                })
                        )
                )
                .then(Commands.literal("status")
                        .executes(ctx -> {
                            boolean connected = CrossChatPlus.getInstance().getChatBridge().isConnected();
                            ctx.getSource().sendSuccess(
                                    Component.literal("§7[CrossChat] 连接状态: " + (connected ? "§a已连接" : "§c未连接")), false);
                            return 1;
                        })
                )
                .then(Commands.literal("reconnect")
                        .executes(ctx -> {
                            CrossChatPlus.getInstance().getChatBridge().disconnect();
                            CrossChatPlus.getInstance().getChatBridge().connect();
                            ctx.getSource().sendSuccess(
                                    Component.literal("§a[CrossChat] 正在重连..."), false);
                            return 1;
                        })
                )
                .then(Commands.literal("reload")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> {
                            CrossChatPlus.getInstance().getConfig().reload();
                            CrossChatPlus.getInstance().getChatBridge().disconnect();
                            CrossChatPlus.getInstance().getChatBridge().connect();
                            ctx.getSource().sendSuccess(
                                    Component.literal("§a[CrossChat] 配置已重载"), false);
                            return 1;
                        })
                )
                .then(Commands.literal("theme")
                        .then(Commands.argument("name", StringArgumentType.word())
                                .executes(ctx -> {
                                    String name = StringArgumentType.getString(ctx, "name");
                                    CrossChatPlus.getInstance().getThemeManager().setTheme(name);
                                    ctx.getSource().sendSuccess(
                                            Component.literal("§a主题已切换为: " + name), false);
                                    return 1;
                                })
                        )
                )
                .then(Commands.literal("help")
                        .executes(ctx -> {
                            ctx.getSource().sendSuccess(
                                    Component.literal("""
                                            §6=== CrossChatPlus 帮助 ===
                                            §e/crosschat send <消息> §7- 发送跨服聊天
                                            §e/crosschat status §7- 查看连接状态
                                            §e/crosschat reconnect §7- 重连聊天桥
                                            §e/crosschat theme <名称> §7- 切换主题
                                            §e/crosschat reload §7- 重载配置 (OP)
                                            """), false);
                            return 1;
                        })
                )
        );

        // 快捷别名
        dispatcher.register(Commands.literal("cc")
                .then(Commands.argument("message", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String msg = StringArgumentType.getString(ctx, "message");
                            CrossChatPlus.getInstance().getChatBridge().sendChat(msg);
                            return 1;
                        })
                )
        );
    }

    public static void register() {
        // 由 @SubscribeEvent 自动注册
    }
}
