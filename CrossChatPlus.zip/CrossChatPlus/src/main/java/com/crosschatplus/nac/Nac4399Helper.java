package com.crosschatplus.nac;

import com.crosschatplus.config.ModConfig;
import com.crosschatplus.CrossChatPlus;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Nac4399 随机账号获取（对应 Fantnel 的 Nac4399 模块）
 * 从配置的 API 获取随机 Minecraft 账号供用户使用
 */
public class Nac4399Helper {
    private final ModConfig config;
    private final Gson gson = new Gson();

    public Nac4399Helper(ModConfig config) {
        this.config = config;
    }

    /**
     * 获取一个随机账号
     * @return Account 对象，失败返回 null
     */
    public Account fetchRandomAccount() {
        if (!config.nac4399Enabled) {
            CrossChatPlus.LOGGER.warn("Nac4399 is disabled in config.");
            return null;
        }

        try {
            URL url = new URL(config.nac4399ApiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("User-Agent", "CrossChatPlus/1.0");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            if (code != 200) {
                CrossChatPlus.LOGGER.warn("Nac4399 API returned HTTP {}", code);
                return null;
            }

            String body;
            try (InputStream in = conn.getInputStream()) {
                body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            conn.disconnect();

            JsonObject json = JsonParser.parseString(body).getAsJsonObject();
            Account account = new Account();
            account.username = json.get("username").getAsString();
            account.password = json.get("password").getAsString();
            account.email = json.has("email") ? json.get("email").getAsString() : "";
            account.expiresAt = json.has("expiresAt") ? json.get("expiresAt").getAsLong() : 0;

            CrossChatPlus.LOGGER.info("Fetched random account: {}", account.username);
            return account;
        } catch (Exception e) {
            CrossChatPlus.LOGGER.error("Failed to fetch Nac4399 account", e);
            return null;
        }
    }

    public static class Account {
        public String username;
        public String password;
        public String email;
        public long expiresAt;

        public boolean isValid() {
            return username != null && !username.isEmpty()
                    && password != null && !password.isEmpty();
        }
    }
}
