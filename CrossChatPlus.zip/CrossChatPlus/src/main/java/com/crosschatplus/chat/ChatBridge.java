package com.crosschatplus.chat;

import com.crosschatplus.config.ModConfig;
import com.crosschatplus.CrossChatPlus;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.eventbus.api.IEventBus;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Timer;
import java.util.TimerTask;

public class ChatBridge {
    private final ModConfig config;
    private final IEventBus eventBus;
    private WebSocketClient wsClient;
    private Timer reconnectTimer;
    private int reconnectAttempts = 0;
    private boolean intentionalClose = false;

    public ChatBridge(ModConfig config, IEventBus eventBus) {
        this.config = config;
        this.eventBus = eventBus;
    }

    public void connect() {
        if (!config.chatBridgeEnabled) {
            CrossChatPlus.LOGGER.info("Chat bridge disabled in config.");
            return;
        }
        if (wsClient != null && wsClient.isOpen()) return;

        intentionalClose = false;
        try {
            URI uri = new URI(config.wsUrl);
            wsClient = new WebSocketClient(uri) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    reconnectAttempts = 0;
                    CrossChatPlus.LOGGER.info("Chat bridge connected to {}", config.wsUrl);
                    sendRaw("{\"type\":\"join\",\"nick\":\"" + escapeJson(config.nickname) + "\",\"version\":\"1.0.0\"}");
                    Minecraft.getInstance().player.displayClientMessage(
                            Component.literal("§a[CrossChat] 已连接到跨服聊天桥"), false);
                }

                @Override
                public void onMessage(String message) {
                    try {
                        JsonObject json = JsonParser.parseString(message).getAsJsonObject();
                        String type = json.get("type").getAsString();
                        if ("chat".equals(type)) {
                            String sender = json.get("sender").getAsString();
                            String content = json.get("content").getAsString();
                            String prefix = config.showCrossChatPrefix ? config.crossChatPrefix + " " : "";
                            Minecraft.getInstance().player.displayClientMessage(
                                    Component.literal(prefix + "§7<§f" + sender + "§7> §r" + content), false);
                        } else if ("system".equals(type)) {
                            String msg = json.get("message").getAsString();
                            Minecraft.getInstance().player.displayClientMessage(
                                    Component.literal("§7[系统] §r" + msg), false);
                        }
                    } catch (Exception e) {
                        CrossChatPlus.LOGGER.warn("Failed to parse chat message: {}", message);
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    CrossChatPlus.LOGGER.info("Chat bridge disconnected: {} (code={}, remote={})", reason, code, remote);
                    if (!intentionalClose) {
                        scheduleReconnect();
                    }
                }

                @Override
                public void onError(Exception ex) {
                    CrossChatPlus.LOGGER.error("Chat bridge error: {}", ex.getMessage());
                }
            };

            wsClient.setConnectionLostTimeout(30);
            wsClient.connect();
        } catch (URISyntaxException e) {
            CrossChatPlus.LOGGER.error("Invalid WebSocket URL: {}", config.wsUrl);
        }
    }

    public void disconnect() {
        intentionalClose = true;
        if (reconnectTimer != null) {
            reconnectTimer.cancel();
            reconnectTimer = null;
        }
        if (wsClient != null) {
            wsClient.close();
        }
    }

    public void sendChat(String content) {
        if (wsClient == null || !wsClient.isOpen()) {
            Minecraft.getInstance().player.displayClientMessage(
                    Component.literal("§c[CrossChat] 未连接到聊天桥"), false);
            return;
        }
        JsonObject msg = new JsonObject();
        msg.addProperty("type", "chat");
        msg.addProperty("sender", config.nickname);
        msg.addProperty("content", content);
        sendRaw(msg.toString());
    }

    private void sendRaw(String message) {
        if (wsClient != null && wsClient.isOpen()) {
            wsClient.send(message);
        }
    }

    private void scheduleReconnect() {
        int max = config.maxReconnectAttempts;
        if (max > 0 && reconnectAttempts >= max) {
            CrossChatPlus.LOGGER.warn("Max reconnect attempts ({}) reached, stopping.", max);
            return;
        }
        reconnectAttempts++;
        if (reconnectTimer == null) reconnectTimer = new Timer(true);
        reconnectTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                CrossChatPlus.LOGGER.info("Reconnecting... (attempt {})", reconnectAttempts);
                connect();
            }
        }, config.reconnectDelayMs);
    }

    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public boolean isConnected() {
        return wsClient != null && wsClient.isOpen();
    }
}
